//print odds up to 20
/*for(var i =1; i <= 20; i ++){
    if(i % 2 != 0){
    console.log(i)
    }
}*/

// decrease multiples of 3 starting at 100
/*for (var i = 100; i > 3; i-=3){
    console.log(i)
}*/


// print sequence 4, 2.5, 1, -0.5, -2, -3.5.//
/*for (var i = 4; i> -4; i -= 1.5){
    console.log(i)
}*/

//sigma - add values from 1-100 to a var sum
/*var x = 0;
for(var i = 1; i <= 100; i++){
    x += i;
}
console.log(x);*/

//factorial - multiply values from 1-12 onto a product
/*var x = 1;
for(var i = 1; i <=12; i++){
    x = x*i;
}
console.log(x)*/